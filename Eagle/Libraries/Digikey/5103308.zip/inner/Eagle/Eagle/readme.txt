 
 
 
**********************************************************
*************  Important Instructions Follow  ************
**********************************************************
 
All files exported to: C:\ul_temp\9fbd25fd4b1237edb1977399b71756e2-1469761\inner\Eagle\Eagle\Eagle.xml
 
 
To import your new library into Eagle:
1. Start Eagle.
2. Select File -> New -> Library from the menu.
3. In the blank library window, select File -> Execute Script from the menu.
5. Browse to your newly exported Eagle Script file (".scr" file extension)
6. After opening the file, the script will populate the new library.
7. Use File -> Save (or Save As..) to save the library to the desired location in Eagle native format.

For additional information, please visit this site:
http://www.accelerated-designs.com/help/Eagle_import.html

You may also find this video helpful:
http://youtu.be/5jGuWY-Yy3Q
 
 
Component "5103308-3" renamed to "5103308-3"
The Symbol con16_2X8_S4 was missing a Value attribute, a value was created for the symbol.


Ultra Librarian Gold 8.1.179 Process Report


Message - Pattern "con16_2X8_S4", entity (37-LINE) is on a non-existant layer number (0).
Message - Pattern "con16_2X8_S4", entity (38-LINE) is on a non-existant layer number (0).
Message - Pattern "con16_2X8_S4", entity (39-LINE) is on a non-existant layer number (0).
Message - Pattern "con16_2X8_S4", entity (40-LINE) is on a non-existant layer number (0).
Message - Pattern "con16_2X8_S4", entity (41-LINE) is on a non-existant layer number (0).
Message - Pattern "con16_2X8_S4", entity (125-LINE) is on a non-existant layer number (0).
Message - Pattern "con16_2X8_S4", entity (126-LINE) is on a non-existant layer number (0).
Message - Pattern "con16_2X8_S4", entity (127-LINE) is on a non-existant layer number (0).
Message - Pattern "con16_2X8_S4", entity (128-LINE) is on a non-existant layer number (0).
Message - Pattern "con16_2X8_S4", entity (129-LINE) is on a non-existant layer number (0).
Message - Pattern "con16_2X8_S4", entity (133-LINE) is on a non-existant layer number (0).
Message - Pattern "con16_2X8_S4", entity (134-LINE) is on a non-existant layer number (0).
Message - Pattern "con16_2X8_S4", entity (135-LINE) is on a non-existant layer number (0).
Message - Pattern "con16_2X8_S4", entity (136-LINE) is on a non-existant layer number (0).
Message - Pattern "con16_2X8_S4", entity (137-LINE) is on a non-existant layer number (0).

TextStyle count:  25
Padstack count:   2
Pattern count:    1
Symbol count:     1
Component count:  1

Export


